﻿using UnityEngine;
using System.Collections;

public class GoodGuy : MonoBehaviour {
	public Color powerColor = Color.magenta;
	public Color normColor = Color.blue;
	public Renderer rend;
	public UnityEngine.AI.NavMeshAgent navMeshAgent;
	public float powerUpTime = 10f;
	public float powerUpCooldown = 30f;
	public float distance = 5f;
	public float turnspeed = 15f;
	public Camera cam;
	public Transform target;
	public float verticalDistance = 50f;

	void Start () {
		rend = GetComponent<Renderer> ();
		navMeshAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
		//rend.material.color = myColor;
		
	}

	void Update () {

		if(Input.GetKey(KeyCode.W)){

			transform.position = transform.position + cam.transform.forward * distance * Time.deltaTime;
			Vector3 dir = target.position - transform.position;
			Quaternion lookRotation = Quaternion.LookRotation (dir);
			Vector3 rotation = Quaternion.Lerp(transform.rotation,lookRotation,Time.deltaTime*turnspeed).eulerAngles;
			transform.rotation = Quaternion.Euler (0f, rotation.y, 0f);


		}

		if(Input.GetKey(KeyCode.D)){
			transform.position = transform.position + cam.transform.right * distance * Time.deltaTime;
			Vector3 dir = target.position- transform.position ;
			Quaternion lookRotation = Quaternion.LookRotation(dir);
			lookRotation *=Quaternion.Euler(0,90,0);
			Vector3 rotation = Quaternion.Lerp(transform.rotation,lookRotation,Time.deltaTime*turnspeed).eulerAngles;
			transform.rotation = Quaternion.Euler (0f, rotation.y , 0f);

		}

		if(Input.GetKey(KeyCode.A)){
			transform.position = transform.position + cam.transform.right * -distance * Time.deltaTime;
			Vector3 dir = target.position- transform.position ;
			Quaternion lookRotation = Quaternion.LookRotation (dir);
			lookRotation *=Quaternion.Euler(0,-90,0);
			Vector3 rotation = Quaternion.Lerp(transform.rotation,lookRotation,Time.deltaTime*turnspeed).eulerAngles;
			transform.rotation = Quaternion.Euler (0f, rotation.y, 0f);

		}

		if(Input.GetKey(KeyCode.S)){
			transform.position = transform.position + cam.transform.forward * -distance * Time.deltaTime;
			Vector3 dir = target.position- transform.position ;
			Quaternion lookRotation = Quaternion.LookRotation (dir);
			Vector3 rotation = Quaternion.Lerp(transform.rotation,lookRotation,Time.deltaTime*turnspeed).eulerAngles;
			transform.rotation = Quaternion.Euler (0f, rotation.y, 0f);

		}


		if(Input.GetKeyDown(KeyCode.Space)){
			
			print ("jump");
		}


		if(Input.GetKeyDown(KeyCode.J)){
			print ("attack");

		}


		if(Input.GetKeyDown(KeyCode.K)){
			print ("leftshift");

		}

		if(Input.GetKeyDown(KeyCode.L)){
			print ("rightshift");

		}



		/*
		if (powerUpTime == 10f && powerUpCooldown == 30f) {
			if (Input.GetKeyDown (KeyCode.Space)) {
				rend.material.color = powerColor;
				powerUpTime = 0f;
				powerUpCooldown = 0f;
			}
		}

		if (powerUpTime < 10f) {
			powerUpTime += Time.deltaTime;
		} else {
			rend.material.color = normColor;
			powerUpTime = 10f;
		}
		

		if (powerUpCooldown < 30f) {
			powerUpCooldown += Time.deltaTime;
		} else
			powerUpCooldown = 30f;




		if (rend.material.color == Color.magenta) {
			navMeshAgent.speed = 20;
			navMeshAgent.angularSpeed = 50;
			navMeshAgent.acceleration = 600;
			distance = 30;
		} else {
			navMeshAgent.speed = 10;
			navMeshAgent.angularSpeed = 30;
			distance = 5;
		}

*/
		
	}
}
